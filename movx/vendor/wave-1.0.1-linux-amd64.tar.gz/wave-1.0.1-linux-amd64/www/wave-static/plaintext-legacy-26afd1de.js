System.register([],(function(t,e){"use strict";return{execute:function(){t("default",(function(t){return{name:"Plain text",aliases:["text","txt"],disableAutodetect:!0}}))}}}));
